package com.spring.login.repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.login.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{
}